import { Navbar } from '../components/Navbar'
import Add from '../components/Add'
import Footer from '../components/Footer'
import styled from 'styled-components'

const Div = styled.div`
    display : flex;
    flex-direction : column;
    justify-content : space-evenly;
    align-items : center;
    height : 200 px;
`;

const Home = () => {
    return (
        <Div>
            <Navbar></Navbar>
            <Add></Add>
            <Footer></Footer>
        </Div>
    )
}

export default Home

import React from 'react'
import AdminStock from '../components/AdminStock'

const Adminpage = () => {
    return (
        <div>
            <AdminStock></AdminStock>
        </div>
    )
}


export default Adminpage

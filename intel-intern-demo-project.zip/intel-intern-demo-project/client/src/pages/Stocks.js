import React from 'react'
import styled from 'styled-components'
import Stock from '../components/stocks'
import { Navbar } from '../components/Navbar'

const DIV = styled.div`
    display : flex;
    flex-direction : column;
    align-items : center;
    justify-content : space-evenly;
`;
const Stocks = () => {
    return (
        <DIV>
            <Navbar></Navbar>
            <h2> Stocks</h2>
            <Stock></Stock>
        </DIV>
    )
}
export default Stocks
export let usersObj = {
    users: {
        "abc": {
            "username":"abc",
            "password": 123,
            "role": "user",
            stocks:
                [
                    {
                        "id": 1,
                        "fullName": "Apple",
                        "ticker": "AAPL",
                        "volume": 12,
                        "price": 112
                    },
                    {
                        "id": 2,
                        "fullName": "Amazon",
                        "ticker": "AMZN",
                        "volume": 12,
                        "price": 12
                    }
                ],
            "cash": 5008
        },
        "admin": {
            "username" : "admin",
            "password": 123,
            "role": "admin",
            stocks:
                [
                    {
                        "id": 3,
                        "fullName": "Google",
                        "ticker": "GOOG",
                        "volume": 21,
                        "price": 244
                    },
                    {
                        "id": 2,
                        "fullName": "Amazon",
                        "ticker": "AMZN",
                        "volume": 14,
                        "price": 14
                    }
                ],
            "cash": 1000
        }

    }
}
export var dataObj = [
    {
        "id": 1,
        "fullName": "Apple",
        "ticker": "AAPL",
        "volume": 7516,
        "price": 10
    },
    {
        "id": 2,
        "fullName": "Amazon",
        "ticker": "AMZN",
        "volume": 7518,
        "price": 12
    },
    {
        "id": 3,
        "fullName": "Google",
        "ticker": "GOOG",
        "volume": 3939,
        "price": 14
    }
]
import { useEffect, useState } from "react";
import { Link } from "react-router-dom"
import { Text, Nav, Li } from "./NavbarElem"


export const Navbar = () => {
    const [login, setlogin] = useState('Login');
    const [userloggedin, setuserloggedin] = useState(0);
    const [role, setRole] = useState('admin');
    useEffect(() => {
        const loggedInUser = localStorage.getItem("userdetails");
        if (JSON.parse(loggedInUser)) {
            setuserloggedin(1);
            const curruser = JSON.parse(loggedInUser);
            console.log(curruser);
            setRole(curruser.role.toLowerCase());
            setlogin(curruser.username);
        }
    }, []);
    const logout = () => {
        localStorage.clear();
        setuserloggedin(0);
        setRole('')
        setlogin('Login')
    }

    return (
        <div>
            <Nav className="snav">
                <Li><Link to="/" style={{ textDecoration: 'none' }}>Home</Link></Li>
                <Li><Link to="/stocks" style={{ textDecoration: 'none' }}>Your Stocks</Link></Li>
                {userloggedin ?
                    
                    <button onClick={logout} style={{ textDecoration: 'none', border: 'none' }}>Logout {login}</button> :
                    <Li><Link to="/login" style={{ textDecoration: 'none' }}>{login}</Link></Li>
                }
                
                {role === 'admin' ? <Li><Link to='/admin' style={{ textDecoration: 'none' }}>Adminfunc</Link></Li> : null}
            </Nav>
        </div>
    )
}

import React, { useState, Fragment } from "react";
import { nanoid } from "nanoid";
import { dataObj, usersObj } from "../../db";
import ReadOnlyRow from "./ReadOnlyRow";
import EditableRow from "./EditableRow";
import styled from "styled-components";


const Div = styled.div`
  display : flex;
  flex-direction : column;
  justify-content : center;
  align-items : center;
  padding : 2%;
`;
const Styles = styled.div`
  padding: 1rem;
  table {
    width : 70vw;
    border-radius: 25px;
    box-shadow: -8px -8px 8px #fff,8px 8px 8px #cbced1;
    border: 1px solid #EBEBED;
    tr {
      :last-child {
        td {
          border-bottom: 0;/
        }
      }
    }
    button {
        cursor: pointer;
        width: 100%;
        border-radius: 5px;
        font-weight: 700;
        font-family: 'Lato', sans-serif;
        color: #fff;
        text-align: center;
        background-color: #448a96;
        transition: all 0.5s;
        &:hover {
            background-color: #337180;
          }
        &:active {
            background-color: #88ef9e;
        }
    }
    th{
        background-color : #EBEBED;
        border-radius : 25px;
    },
    td {
      margin: 0;
      padding: 0.5rem;
      border-bottom: 2px solid #EBEBED;
      border-right: 2px solid #EBEBED;
      :last-child {
        border-right: 0;
      }
    }
  }
`;
const Stock = () => {
  const [stocks, setStocks] = useState(JSON.parse(localStorage.getItem("userdetails")).stocks);
  const [cash, setCash] = useState(JSON.parse(localStorage.getItem("userdetails")).cash);
  const [addFormData, setAddFormData] = useState({
    fullName: "",
    ticker: "",
    volume: "",
    price: "",
  });
  

  const [editFormData, setEditFormData] = useState({
    fullName: "",
    ticker: "",
    volume: "",
    price: "",
  });
  const [editStockId, setEditStockId] = useState(null);
  console.log(stocks,'arghhhhhhh')
  const handleAddFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;

    const newFormData = { ...addFormData };
    newFormData[fieldName] = fieldValue;

    setAddFormData(newFormData);
  };

  const handleEditFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;
    const newFormData = { ...editFormData };
    newFormData[fieldName] = fieldValue;
    const difference = fieldValue - editFormData[fieldName]
    setCash(cash-difference*editFormData.price)
    setEditFormData(newFormData);
  };

  const handleAddFormSubmit = (event) => {
    event.preventDefault();

    const newStock = {
      id: nanoid(),
      fullName: addFormData.fullName,
      ticker: addFormData.ticker,
      volume: addFormData.volume,
      price: addFormData.price,
    };

    const newStocks = [...stocks, newStock];
    dataObj.push(newStock);
    setStocks(newStocks);
  };

  const handleEditFormSubmit = (event) => {
    event.preventDefault();

    const editedStock = {
      id: editStockId,
      fullName: editFormData.fullName,
      ticker: editFormData.ticker,
      volume: editFormData.volume,
      price: editFormData.price,
    };

    const newStocks = [...stocks];

    const index = stocks.findIndex((Stock) => Stock.id === editStockId);

    newStocks[index] = editedStock;

    setStocks(newStocks);
    setEditStockId(null);
  };

  const handleEditClick = (event, Stock) => {
    event.preventDefault();
    setEditStockId(Stock.id);
    console.log(JSON.parse(localStorage.getItem("userdetails")).stocks);

    const formValues = {
      fullName: Stock.fullName,
      ticker: Stock.ticker,
      volume: Stock.volume,
      price: Stock.price,
    };

    setEditFormData(formValues);
  };

  const handleCancelClick = () => {
    setEditStockId(null);
  };

  const handleDeleteClick = (StockId) => {
    const newStocks = [...stocks];

    const index = stocks.findIndex((Stock) => {return Stock.id === StockId});
    setCash(cash+(stocks[index].volume*stocks[index].price));

    newStocks.splice(index, 1);

    setStocks(newStocks);
  };

  return (
    <Styles>
      <Div>
        <div className="app-container">
          <form onSubmit={handleEditFormSubmit}>
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Ticker</th>
                  <th>Volume</th>
                  <th>Price</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {stocks.map((Stock) => (
                  <Fragment>
                    {editStockId === Stock.id ? (
                      <EditableRow
                        editFormData={editFormData}
                        handleEditFormChange={handleEditFormChange}
                        handleCancelClick={handleCancelClick}
                      />
                    ) : (
                      <ReadOnlyRow
                        Stock={Stock}
                        handleEditClick={handleEditClick}
                        handleDeleteClick={handleDeleteClick}
                      />
                    )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </form>

          <h2>Your Total Cash : ${cash} </h2>
        </div>
      </Div>
    </Styles>
  );
};

export default Stock;

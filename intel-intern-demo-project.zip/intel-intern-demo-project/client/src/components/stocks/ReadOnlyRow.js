import React from "react";

const ReadOnlyRow = ({ Stock, handleEditClick, handleDeleteClick }) => {
  return (
    <tr>
      <td>{Stock.fullName}</td>
      <td>{Stock.ticker}</td>
      <td>{Stock.volume}</td>
      <td>{Stock.price}</td>
      <td>
        <button
          type="button"
          onClick={(event) => handleEditClick(event, Stock)}
        >
          Buy
        </button>
        <button type="button" onClick={() => handleDeleteClick(Stock.id)}>
          Sell
        </button>
      </td>
    </tr>
  );
};

export default ReadOnlyRow;

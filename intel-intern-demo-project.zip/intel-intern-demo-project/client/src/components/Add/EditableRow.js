import React from "react";

const EditableRow = ({
  editFormData,
  handleEditFormChange,
  handleCancelClick,
}) => {
  return (
    <tr>
      <td>

        ${editFormData.fullName}

      </td>
      <td>
        ${editFormData.ticker}
      </td>
      <td>
        <input
          type="text"
          required="required"
          placeholder="Enter volume..."
          name="volume"
          value={editFormData.volume}
          onChange={handleEditFormChange}
        ></input>
      </td>
      <td>
        ${editFormData.price}
      </td>
      <td>
        <button type="submit">Confirm</button>
        <button type="button" onClick={handleCancelClick}>
          Cancel
        </button>
      </td>
    </tr>
  );
};

export default EditableRow;

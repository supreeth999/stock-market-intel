import { Input } from "./Input";
import { Cusdiv, Text } from "./Cusdiv";
import { Div } from "./Div";
import { Button } from "./Button";
import { useState } from "react";
import axios from "axios";
import { useHistory } from "react-router-dom"
import { Link } from "react-router-dom";
import { usersObj } from '../../db';

function Login() {
    let [uname, setName] = useState('abc')
    let [pass, setPass] = useState('123')
    let history = useHistory();
    function senddata(e) {
        let response;
        if (usersObj.users[uname].password == pass) {
            response = usersObj.users[uname];
            localStorage.setItem('userdetails', JSON.stringify(response));
            history.push('/');
        }

    }

    return (
        <Div>
            <Cusdiv>
                <Text>Login</Text>
                <Input placeholder="UserName or E-mail" value={uname} onChange={e => setName(e.target.value)} ></Input>
                <Input type="password" placeholder="Password" value={pass} onChange={e => setPass(e.target.value)}></Input>
                <Button onClick={senddata}>Login</Button>
                <h5>  No account <Link to="/signup">SignUp Now</Link></h5>
            </Cusdiv>
        </Div>
    );

}
export default Login;

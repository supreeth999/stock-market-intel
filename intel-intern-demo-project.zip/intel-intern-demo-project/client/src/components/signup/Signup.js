import { Input } from "./Input";
import { Cusdiv, Text } from "./Cusdiv";
import { Div } from "./Div";
import { useState } from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";
import { usersObj } from '../../db';
import { useHistory } from "react-router-dom"



const Button = styled.button`
outline: none;
border: none;
cursor: pointer;
width: 90%;
height: 60px;
border-radius: 30px;
font-size: 130%;
font-weight: 700;
font-family: 'Lato', sans-serif;
color: #fff;
text-align: center;
background-color: #448a96;
box-shadow: 3px 3px 8px #b1b1b1, -3px -3px 8px #fff;
transition: all 0.5s;
&:hover {
    background-color: #337180;
  }
&:active {
    background-color: #88ef9e;
}
`;
const Select = styled.select`
width: 93 %;
border: none;
outline: none;
background: none;
font-size: 18px;
color: #555;
border: 4px solid #EBEBED;
padding: 5%;
margin-top : 1%;
margin-bottom: 5%;
border-radius: 25px;
box-shadow: inset 8px 8px 8px #cbced1, inset -8px -8px 8px #fff;
`;
const Option = styled.option`
`;

function Signup() {
  const [uname, setName] = useState('abc')
  const [pass, setPass] = useState(123)
  const [role, setRole] = useState('user')
  const [email, setEmail] = useState('clear@gmail.com')
  const [phone, setphone] = useState(343344)
  let history = useHistory();

  function senddata(e) {
    var detail = {
      username : uname,
      password: pass,
      role: role,
      email: email,
      phone: phone
    }
    usersObj.users[uname] = detail;
    console.log(usersObj);
    var response = detail;
    response.uname = uname;
    localStorage.setItem('userdetails', JSON.stringify(response));
    history.push('/');

  }

  return (
    <Div>
      <Cusdiv>
        <Text>Sign up</Text>
        <Input placeholder="User Name" value={uname} onChange={e => setName(e.target.value)} ></Input>
        <Input type="password" placeholder="Password" value={pass} onChange={e => setPass(e.target.value)}></Input>
        <Input type="text" placeholder="Phone" value={phone} onChange={e => setphone(e.target.value)}></Input>
        <Input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)}></Input>
        <Button onClick={senddata}>Signup</Button>
        <h5>Already a user ? <Link to='/login'> Login</Link></h5>
      </Cusdiv>
    </Div>
  );
}
export default Signup;

import './App.css';
import Login from './components/login/Login.js';
import Home from './pages/Home';
import { Route, BrowserRouter as Router } from "react-router-dom";
import Stocks from './pages/Stocks';
import Signup from './components/signup/Signup';
import Adminpage from './pages/Adminpage';

function App() {
  return (
    <Router>
      <switch>
        <Route path="/" exact component={Home}></Route>
        <Route path="/login" exact component={Login}></Route>
        <Route path = "/stocks" exact component={Stocks}></Route>
        <Route path = "/signup" exact component = {Signup}></Route>
        <Route path = "/admin" exact component = {Adminpage}></Route>
      </switch>
    </Router>
  );
}

export default App;
